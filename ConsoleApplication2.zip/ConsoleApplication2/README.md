![1538359057639](http://t1.aixinxi.net/o_1comlbo5t1ofu1iu1e4buhqe0ma.png-w.jpg)

解决方法：在项目属性->C/C++->语言->符合模式项选否即可。



实验结果截图：



![3](http://t1.aixinxi.net/o_1coo3i4itdq78c1cal1k6g1gcca.png-w.jpg)







